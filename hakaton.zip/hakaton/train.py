from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('yolov8m.yaml')
    results = model.train(data=r'C:\hakaton\dataset\config.yaml', epochs=170, device=0)