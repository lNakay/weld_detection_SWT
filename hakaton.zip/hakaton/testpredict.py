import cv2
from ultralytics import YOLO

# Укажите путь к файлам модели
weights_path = r'C:\hakaton\runs\detect\train16\weights\best.pt'  # замените на путь к вашему файлу best.pt

# Загрузите модель
model = YOLO(weights_path)

# Функция для выполнения детекции на изображении
def detect(image_path):
    # Загрузите изображение
    img = cv2.imread(image_path)

    # Выполните детекцию
    results = model(img)
    if not results or all(len(result.boxes) == 0 for result in results):
        notdetect = True
        print("not detected")
    else:
        # Обработайте результаты
        for result in results:
            #print(result.boxes)  # выведите результаты в консоль
            # Нарисуйте bounding boxes на изображении
            for box in result.boxes:
                x1, y1, x2, y2 = box.xyxy[0]
                cls_idx = int(box.cls[0])
                class_name = model.names[cls_idx]
                if class_name != "Good Welding":
                    goodwork = False
                print(f'{class_name}, Координаты: ({x1}, {y1}), ({x2}, {y2})')
                cv2.rectangle(img, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
                cv2.putText(img, class_name, (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
    print(goodwork)

    # Сохраните изображение с результатами
    output_path = r'C:\hakaton\testimages\output.jpg'  # укажите полное имя файла
    cv2.imwrite(output_path, img)
    print(f'Results saved to {output_path}')

# Укажите путь к изображению, на котором хотите выполнить детекцию
image_path = r'C:\hakaton\testimages\IMG_3627_block_2_1_png_jpg.rf.3d32bb81152789a79c6d627637e3eb0f.jpg'  # замените на путь к вашему изображению

# Выполните детекцию
notdetect = False
goodwork = True
detect(image_path)

